import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Radio, Video, LogOut, User, DollarSign, Settings } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/lib/auth-context';
import { signOut } from 'firebase/auth';
import { auth, isFirebaseConfigured } from '@/lib/firebase-client';
import AuthDialog from '@/components/AuthDialog';

/**
 * Header component for LiveStream Platform
 */
export default function Header() {
  const location = useLocation();
  const { user, loading, token } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [activeStream, setActiveStream] = useState<any>(null);

  const navItems = [
    { href: '/', label: 'Browse' },
  ];

  // Check for active stream
  useEffect(() => {
    if (!user || !token) {
      setActiveStream(null);
      return;
    }

    const checkActiveStream = async () => {
      try {
        const response = await fetch('/api/streams/live', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          // Find user's own stream (compare with firebaseUid)
          const myStream = data.streams?.find((s: any) => s.user.firebaseUid === user.uid);
          setActiveStream(myStream || null);
        }
      } catch (error) {
        console.error('Failed to check active stream:', error);
      }
    };

    checkActiveStream();
    
    // Check every 10 seconds
    const interval = setInterval(checkActiveStream, 10000);
    return () => clearInterval(interval);
  }, [user, token]);

  console.log('🔍 Header render:', {
    isFirebaseConfigured,
    loading,
    hasUser: !!user,
    userEmail: user?.email,
    willShow: !isFirebaseConfigured ? 'Auth Not Configured' : loading ? 'Loading Spinner' : user ? 'User Avatar' : 'Login Button',
  });

  const handleLogout = async () => {
    if (!auth) return;
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 text-xl font-bold text-foreground">
            <Radio className="h-6 w-6 text-primary" />
            <span>LiveStream</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  location.pathname === item.href
                    ? 'text-foreground'
                    : 'text-muted-foreground'
                }`}
              >
                {item.label}
              </Link>
            ))}
            
            {user && activeStream && (
              <Button 
                asChild 
                variant="destructive" 
                size="sm"
                className="animate-pulse"
              >
                <Link to={`/broadcast/${activeStream.id}`}>
                  <Radio className="h-4 w-4 mr-2" />
                  Back to Stream
                </Link>
              </Button>
            )}
            
            {user && !activeStream && (
              <Button asChild variant="default" size="sm">
                <Link to="/go-live">
                  <Video className="h-4 w-4 mr-2" />
                  Go Live
                </Link>
              </Button>
            )}

            {/* User Menu or Login Button */}
            {!isFirebaseConfigured ? (
              <Button variant="outline" size="sm" disabled>
                Auth Not Configured
              </Button>
            ) : loading ? (
              <div className="h-8 w-8 rounded-full bg-muted animate-pulse" />
            ) : user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>
                        {user.email?.[0].toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to={`/user/${user.uid}`} className="cursor-pointer">
                      <User className="h-4 w-4 mr-2" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/profile/edit" className="cursor-pointer">
                      <Settings className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/earnings" className="cursor-pointer">
                      <DollarSign className="h-4 w-4 mr-2" />
                      Earnings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/account/settings" className="cursor-pointer">
                      <Settings className="h-4 w-4 mr-2" />
                      Account Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="default" size="sm" onClick={() => setAuthDialogOpen(true)}>
                Login
              </Button>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 hover:bg-accent rounded-md transition-colors"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-border py-4">
            <nav className="flex flex-col gap-2">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  to={item.href}
                  className={`text-sm font-medium transition-colors hover:text-primary py-2 ${
                    location.pathname === item.href
                      ? 'text-foreground'
                      : 'text-muted-foreground'
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              
              {user ? (
                <>
                  {activeStream ? (
                    <Link
                      to={`/broadcast/${activeStream.id}`}
                      className="mt-2"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Button variant="destructive" size="sm" className="w-full animate-pulse">
                        <Radio className="h-4 w-4 mr-2" />
                        Back to Stream
                      </Button>
                    </Link>
                  ) : (
                    <Link
                      to="/go-live"
                      className="mt-2"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Button variant="default" size="sm" className="w-full">
                        <Video className="h-4 w-4 mr-2" />
                        Go Live
                      </Button>
                    </Link>
                  )}
                  
                  <Link
                    to={`/user/${user.uid}`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      <User className="h-4 w-4 mr-2" />
                      Profile
                    </Button>
                  </Link>
                  
                  <Link
                    to="/profile/edit"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      <Settings className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                  </Link>
                  
                  <Link
                    to="/earnings"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      <DollarSign className="h-4 w-4 mr-2" />
                      Earnings
                    </Button>
                  </Link>
                  
                  <Link
                    to="/account/settings"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      <Settings className="h-4 w-4 mr-2" />
                      Account Settings
                    </Button>
                  </Link>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => {
                      handleLogout();
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </>
              ) : (
                <Button
                  variant="default"
                  size="sm"
                  className="w-full mt-2"
                  onClick={() => {
                    setAuthDialogOpen(true);
                    setIsMobileMenuOpen(false);
                  }}
                >
                  Login
                </Button>
              )}
            </nav>
          </div>
        )}
      </div>

      {/* Auth Dialog */}
      <AuthDialog open={authDialogOpen} onOpenChange={setAuthDialogOpen} />
    </header>
  );
}
