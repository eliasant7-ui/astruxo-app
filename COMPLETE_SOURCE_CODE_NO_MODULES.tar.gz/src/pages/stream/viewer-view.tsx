/**
 * Viewer View Component
 * Agora video integration for audience
 */

import { useEffect, useRef, useState } from 'react';
import AgoraRTC, { IAgoraRTCClient } from 'agora-rtc-sdk-ng';
import { AlertCircle, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ViewerViewProps {
  credentials: {
    appId: string;
    channelName: string;
    token: string;
    uid: number;
  };
  onError?: (error: string) => void;
}

export default function ViewerView({ credentials, onError }: ViewerViewProps) {
  const [isJoined, setIsJoined] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const clientRef = useRef<IAgoraRTCClient | null>(null);
  const videoContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    joinChannel();

    return () => {
      leaveChannel();
    };
  }, []);

  const joinChannel = async () => {
    try {
      setError(null);

      // Create Agora client with optimized settings
      const client = AgoraRTC.createClient({
        mode: 'live',
        codec: 'vp8',
        role: 'audience',
      });
      
      // Set low latency mode for faster playback
      client.setLowStreamParameter({
        width: 640,
        height: 360,
        framerate: 15,
        bitrate: 500,
      });
      
      clientRef.current = client;

      // Set client role to audience
      await client.setClientRole('audience', { level: 1 }); // Level 1 = low latency

      console.log('🔍 Joining Agora channel as viewer:', {
        appId: credentials.appId,
        channel: credentials.channelName,
        uid: credentials.uid,
      });

      // Listen for remote users
      client.on('user-published', async (user, mediaType) => {
        console.log('👤 Remote user published:', user.uid, mediaType);
        
        // Subscribe to remote user
        await client.subscribe(user, mediaType);
        console.log('✅ Subscribed to remote user:', user.uid);

        if (mediaType === 'video') {
          // Play remote video
          if (videoContainerRef.current) {
            user.videoTrack?.play(videoContainerRef.current);
            setIsPlaying(true);
          }
        }

        if (mediaType === 'audio') {
          // Play remote audio
          user.audioTrack?.play();
        }
      });

      client.on('user-unpublished', (user, mediaType) => {
        console.log('👤 Remote user unpublished:', user.uid, mediaType);
        
        if (mediaType === 'video') {
          setIsPlaying(false);
        }
      });

      client.on('user-left', (user) => {
        console.log('👤 Remote user left:', user.uid);
        setIsPlaying(false);
      });

      // Join the channel
      await client.join(
        credentials.appId,
        credentials.channelName,
        credentials.token,
        credentials.uid
      );

      setIsJoined(true);
      console.log('✅ Joined Agora channel as viewer');
    } catch (err) {
      console.error('❌ Failed to join Agora channel:', err);
      const errorMsg = err instanceof Error ? err.message : 'Failed to connect to stream';
      setError(errorMsg);
      onError?.(errorMsg);
    }
  };

  const leaveChannel = async () => {
    try {
      if (clientRef.current) {
        await clientRef.current.leave();
        clientRef.current = null;
      }

      setIsJoined(false);
      setIsPlaying(false);
      console.log('✅ Left Agora channel');
    } catch (err) {
      console.error('❌ Error leaving channel:', err);
    }
  };

  return (
    <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
      {/* Video container */}
      <div
        ref={videoContainerRef}
        className="absolute inset-0"
        style={{ width: '100%', height: '100%' }}
      />

      {/* Loading overlay */}
      {!isPlaying && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="text-center text-white">
            {isJoined ? (
              <>
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Waiting for broadcaster...</p>
                <p className="text-sm text-gray-400 mt-2">
                  The stream will start when the host goes live
                </p>
              </>
            ) : (
              <>
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
                <p>Connecting to stream...</p>
              </>
            )}
          </div>
        </div>
      )}

      {/* Error overlay */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80">
          <div className="text-center text-white max-w-md px-4">
            <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <p className="font-semibold mb-2">Connection Error</p>
            <p className="text-sm text-gray-300">{error}</p>
            <Button
              variant="secondary"
              className="mt-4"
              onClick={() => {
                setError(null);
                joinChannel();
              }}
            >
              Retry Connection
            </Button>
          </div>
        </div>
      )}

      {/* Status indicator */}
      {isPlaying && (
        <div className="absolute top-4 left-4">
          <div className="flex items-center gap-2 bg-black/50 px-3 py-1.5 rounded-full">
            <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-white text-sm font-medium">LIVE</span>
          </div>
        </div>
      )}
    </div>
  );
}
