/**
 * Stream Viewer Page
 * Watch live stream with Agora player and real-time chat
 */

import { useEffect, useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Users, Radio, Send, Clock, Eye, Gift, UserPlus, UserMinus } from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { toast } from 'sonner';
import ViewerView from './viewer-view';
import GiftSelector from '@/components/GiftSelector';
import GiftAnimation from '@/components/GiftAnimation';
import { useAuth } from '@/lib/auth-context';

interface Stream {
  id: number;
  title: string;
  description: string | null;
  status: string;
  viewerCount: number;
  peakViewerCount: number;
  startedAt: string;
  user: {
    id: number;
    username: string;
    displayName: string | null;
    avatarUrl: string | null;
    followerCount: number;
    isFollowing?: boolean;
  };
}

interface ChatMessage {
  id: number;
  userId: number;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  message: string;
  createdAt: string;
  type?: 'message' | 'join' | 'leave'; // Add type for system messages
}

export default function StreamViewerPage() {
  const { streamId } = useParams<{ streamId: string }>();
  const { user } = useAuth();
  const [stream, setStream] = useState<Stream | null>(null);
  const [credentials, setCredentials] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Chat state
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [messageInput, setMessageInput] = useState('');
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Real-time stats
  const [liveViewerCount, setLiveViewerCount] = useState(0);
  const [streamDuration, setStreamDuration] = useState('0:00');
  
  // Gift selector
  const [giftSelectorOpen, setGiftSelectorOpen] = useState(false);
  
  // Gift notifications
  const [giftNotifications, setGiftNotifications] = useState<any[]>([]);
  
  // Follow state
  const [followLoading, setFollowLoading] = useState(false);

  useEffect(() => {
    if (streamId) {
      fetchStream();
    }
  }, [streamId]);

  useEffect(() => {
    if (!stream || stream.status !== 'live') return;

    // Initialize Socket.IO
    // Use current origin for connection (works in both preview and production)
    const socketUrl = window.location.origin;
    console.log('🔌 Connecting to Socket.IO at:', socketUrl);
    
    const newSocket = io(socketUrl, {
      path: '/socket.io',
      transports: ['websocket', 'polling'], // Try WebSocket first, fallback to polling
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5,
    });

    newSocket.on('connect', () => {
      console.log('✅ Socket connected successfully');
      setIsConnected(true);

      // Authenticate (if user is logged in)
      const token = localStorage.getItem('firebaseToken');
      if (token) {
        console.log('🔐 Authenticating with token...');
        newSocket.emit('authenticate', { token });
      } else {
        console.log('⚠️ No token found, connecting as guest');
      }

      // Join stream room
      console.log('📺 Joining stream room:', streamId);
      newSocket.emit('join_stream', { streamId: parseInt(streamId!) });
    });

    newSocket.on('disconnect', (reason) => {
      console.log('❌ Socket disconnected:', reason);
      setIsConnected(false);
    });

    newSocket.on('connect_error', (error) => {
      console.error('❌ Socket connection error:', error);
      setIsConnected(false);
    });

    newSocket.on('error', (error) => {
      console.error('❌ Socket error:', error);
    });

    newSocket.on('joined_stream', (data: any) => {
      console.log('✅ Joined stream:', data);
    });

    newSocket.on('chat_history', (history: ChatMessage[]) => {
      console.log('📜 Received chat history:', history.length, 'messages');
      setMessages(history);
    });

    newSocket.on('viewer_count', (data: { count: number }) => {
      console.log('👥 Viewer count updated:', data.count);
      setLiveViewerCount(data.count);
    });

    newSocket.on('new_message', (message: ChatMessage) => {
      setMessages((prev) => {
        const newMessages = [...prev, { ...message, type: 'message' as const }];
        // Keep only last 100 messages to prevent memory issues
        return newMessages.slice(-100);
      });
    });

    newSocket.on('user_joined', (data: { username: string; displayName: string }) => {
      const systemMessage: ChatMessage = {
        id: Date.now(),
        userId: 0,
        username: 'System',
        displayName: 'System',
        avatarUrl: null,
        message: `${data.displayName} joined the stream`,
        createdAt: new Date().toISOString(),
        type: 'join',
      };
      setMessages((prev) => {
        const newMessages = [...prev, systemMessage];
        return newMessages.slice(-100);
      });
    });

    newSocket.on('user_left', (data: { username: string; displayName: string }) => {
      const systemMessage: ChatMessage = {
        id: Date.now(),
        userId: 0,
        username: 'System',
        displayName: 'System',
        avatarUrl: null,
        message: `${data.displayName} left the stream`,
        createdAt: new Date().toISOString(),
        type: 'leave',
      };
      setMessages((prev) => {
        const newMessages = [...prev, systemMessage];
        return newMessages.slice(-100);
      });
    });

    newSocket.on('gift_sent', (data: any) => {
      console.log('🎁 Gift received:', data);
      
      // Show toast notification
      toast.success(`${data.senderDisplayName} sent ${data.giftName}!`, {
        description: `${data.coinAmount} coins${data.message ? ` - "${data.message}"` : ''}`,
        duration: 4000,
      });
      
      // Add to gift notifications (show for 5 seconds)
      const notificationId = `gift-${Date.now()}`;
      setGiftNotifications((prev) => [...prev, { ...data, id: notificationId }]);
      
      // Remove notification after 5 seconds
      setTimeout(() => {
        setGiftNotifications((prev) => prev.filter((n) => n.id !== notificationId));
      }, 5000);
      
      // Add system message to chat
      const giftMessage: ChatMessage = {
        id: Date.now(),
        userId: 0,
        username: 'System',
        displayName: 'System',
        avatarUrl: null,
        message: `${data.senderDisplayName} sent ${data.giftName} (${data.coinAmount} coins)${data.message ? `: "${data.message}"` : ''}`,
        createdAt: new Date().toISOString(),
        type: 'join', // Use 'join' type for special styling
      };
      setMessages((prev) => {
        const newMessages = [...prev, giftMessage];
        return newMessages.slice(-100);
      });
    });

    newSocket.on('error', (data: { message: string }) => {
      console.error('Socket error:', data.message);
    });

    setSocket(newSocket);

    return () => {
      if (newSocket) {
        newSocket.emit('leave_stream', { streamId: parseInt(streamId!) });
        newSocket.disconnect();
      }
    };
  }, [stream, streamId]);

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Calculate stream duration
  useEffect(() => {
    if (!stream || stream.status !== 'live') return;

    const updateDuration = () => {
      const startTime = new Date(stream.startedAt || Date.now()).getTime();
      const now = Date.now();
      const diff = Math.floor((now - startTime) / 1000); // seconds
      
      const hours = Math.floor(diff / 3600);
      const minutes = Math.floor((diff % 3600) / 60);
      const seconds = diff % 60;
      
      if (hours > 0) {
        setStreamDuration(`${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
      } else {
        setStreamDuration(`${minutes}:${seconds.toString().padStart(2, '0')}`);
      }
    };

    updateDuration();
    const interval = setInterval(updateDuration, 1000);

    return () => clearInterval(interval);
  }, [stream]);

  const fetchStream = async () => {
    try {
      const token = localStorage.getItem('firebaseToken');
      const response = await fetch(`/api/streams/${streamId}`, {
        headers: token ? {
          Authorization: `Bearer ${token}`,
        } : {},
      });
      const data = await response.json();

      if (data.success) {
        setStream(data.stream);
        
        // Set Agora credentials if available
        if (data.credentials) {
          setCredentials(data.credentials);
        }
        
        setError(null);
      } else {
        setError('Stream not found');
      }
    } catch (err) {
      setError('Failed to load stream');
      console.error('Error fetching stream:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFollow = async () => {
    if (!user || !stream) {
      toast.error('Please login to follow');
      return;
    }

    setFollowLoading(true);
    try {
      const token = localStorage.getItem('firebaseToken');
      const endpoint = stream.user.isFollowing
        ? `/api/users/${stream.user.id}/unfollow`
        : `/api/users/${stream.user.id}/follow`;

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (data.success) {
        // Update local state
        setStream({
          ...stream,
          user: {
            ...stream.user,
            isFollowing: !stream.user.isFollowing,
            followerCount: stream.user.isFollowing 
              ? stream.user.followerCount - 1 
              : stream.user.followerCount + 1,
          },
        });
        
        toast.success(stream.user.isFollowing ? 'Unfollowed' : 'Following!');
      } else {
        toast.error(data.message || 'Failed to update follow status');
      }
    } catch (err) {
      console.error('Follow error:', err);
      toast.error('Failed to update follow status');
    } finally {
      setFollowLoading(false);
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!messageInput.trim() || !socket || !isConnected) return;

    socket.emit('send_message', {
      streamId: parseInt(streamId!),
      message: messageInput.trim(),
    });

    setMessageInput('');
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading stream...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !stream) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="text-center py-12">
          <CardContent>
            <h2 className="text-2xl font-semibold mb-2">Stream Not Found</h2>
            <p className="text-muted-foreground mb-6">{error || 'This stream does not exist'}</p>
            <Button asChild>
              <Link to="/">Back to Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (stream.status === 'ended') {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="text-center py-12">
          <CardContent>
            <Radio className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Stream Ended</h2>
            <p className="text-muted-foreground mb-6">This stream has ended.</p>
            <Button asChild>
              <Link to="/">Browse Live Streams</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <title>{stream.title} - LiveStream Platform</title>
      <meta name="description" content={stream.description || `Watch ${stream.user.displayName || stream.user.username} live`} />

      <div className="container mx-auto px-4 py-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Video Player */}
          <div className="lg:col-span-2 space-y-4">
            {/* Video Container */}
            <Card className="overflow-hidden">
              {credentials ? (
                <ViewerView
                  credentials={credentials}
                  onError={(err) => setError(err)}
                />
              ) : (
                <div className="relative aspect-video bg-black flex items-center justify-center">
                  <div className="text-white text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
                    <p>Loading stream...</p>
                  </div>
                </div>
              )}
            </Card>

            {/* Stream Info */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-2xl mb-2">{stream.title}</CardTitle>
                    {stream.description && (
                      <p className="text-muted-foreground">{stream.description}</p>
                    )}
                  </div>
                  <Badge variant="destructive" className="ml-4 animate-pulse">
                    <Radio className="h-3 w-3 mr-1" />
                    LIVE
                  </Badge>
                </div>
                
                {/* Live Stats */}
                <div className="flex items-center gap-6 mt-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4" />
                    <span className="font-medium">{liveViewerCount || stream.viewerCount}</span>
                    <span>watching</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span className="font-medium">{streamDuration}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span className="font-medium">{stream.peakViewerCount}</span>
                    <span>peak</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link to={`/user/${stream.user.id}`} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                  <Avatar>
                    <AvatarImage src={stream.user.avatarUrl || undefined} />
                    <AvatarFallback>
                      {stream.user.displayName?.[0] || stream.user.username[0].toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{stream.user.displayName || stream.user.username}</p>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {stream.user.followerCount} followers
                    </p>
                  </div>
                </Link>
                
                {/* Follow Button */}
                {user && (
                  <Button
                    onClick={handleFollow}
                    disabled={followLoading}
                    variant={stream.user.isFollowing ? 'outline' : 'default'}
                    className="w-full"
                    size="sm"
                  >
                    {followLoading ? (
                      'Loading...'
                    ) : stream.user.isFollowing ? (
                      <>
                        <UserMinus className="h-4 w-4 mr-2" />
                        Unfollow
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4 mr-2" />
                        Follow
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Chat Sidebar */}
          <div className="lg:col-span-1">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Live Chat</span>
                  <Badge 
                    variant={isConnected ? 'default' : 'secondary'}
                    className={isConnected ? 'bg-green-500' : 'animate-pulse'}
                  >
                    {isConnected ? '✓ Connected' : '⏳ Connecting...'}
                  </Badge>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="flex-1 flex flex-col p-0">
                {/* Messages */}
                <ScrollArea className="flex-1 px-4">
                  <div className="space-y-3 py-4">
                    {messages.length === 0 && (
                      <p className="text-center text-muted-foreground text-sm">
                        No messages yet. Be the first to chat!
                      </p>
                    )}
                    {messages.map((msg) => {
                      // System messages (join/leave notifications)
                      if (msg.type === 'join' || msg.type === 'leave') {
                        return (
                          <div key={msg.id} className="text-center py-1">
                            <p className="text-xs text-muted-foreground italic">
                              {msg.message}
                            </p>
                          </div>
                        );
                      }
                      
                      // Regular chat messages
                      return (
                        <div key={msg.id} className="flex gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={msg.avatarUrl || undefined} />
                            <AvatarFallback className="text-xs">
                              {msg.displayName[0] || msg.username[0].toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium">{msg.displayName}</p>
                            <p className="text-sm break-words">{msg.message}</p>
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Gift Button */}
                <div className="px-4 pt-4 border-t">
                  <Button
                    onClick={() => setGiftSelectorOpen(true)}
                    variant="outline"
                    className="w-full"
                  >
                    <Gift className="h-4 w-4 mr-2" />
                    Send a Gift
                  </Button>
                </div>

                {/* Message Input */}
                <div className="p-4">
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    <Input
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      placeholder="Send a message..."
                      maxLength={500}
                      disabled={!isConnected}
                    />
                    <Button type="submit" size="icon" disabled={!messageInput.trim() || !isConnected}>
                      <Send className="h-4 w-4" />
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Gift Selector Modal */}
        <GiftSelector
          open={giftSelectorOpen}
          onOpenChange={setGiftSelectorOpen}
          streamId={stream.id}
          onGiftSent={(gift, message) => {
            // Emit gift event via Socket.IO
            if (socket) {
              socket.emit('send_gift', {
                streamId: stream.id,
                giftName: gift.name,
                giftIcon: gift.icon,
                coinAmount: gift.coinPrice,
                message,
              });
            }
          }}
        />

        {/* Gift Animations */}
        <GiftAnimation notifications={giftNotifications} />
      </div>
    </>
  );
}
