/**
 * Go Live Page
 * Interface for creators to start a live stream
 */

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Radio, Video } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';

export default function GoLivePage() {
  const navigate = useNavigate();
  const { user, refreshToken } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
  });

  // Function to sync user to database
  const handleSyncUser = async () => {
    if (!user) {
      setError('Please login first');
      return;
    }

    setSyncing(true);
    setError(null);

    try {
      const token = await refreshToken();
      
      if (!token) {
        setError('Failed to authenticate. Please login again.');
        setSyncing(false);
        return;
      }

      const response = await fetch('/api/auth/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (data.success) {
        setSyncSuccess(true);
        setError(null);
        alert('✅ User synced successfully! You can now create streams.');
      } else {
        setError(data.message || 'Failed to sync user');
      }
    } catch (err) {
      console.error('Sync error:', err);
      setError(err instanceof Error ? err.message : 'Failed to sync user');
    } finally {
      setSyncing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      setError('Please enter a stream title');
      return;
    }

    if (!user) {
      setError('Please login to start streaming');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Refresh token to ensure it's valid
      console.log('🔄 Refreshing token before starting stream...');
      const token = await refreshToken();
      
      console.log('🔍 Token details:', {
        hasToken: !!token,
        tokenLength: token?.length,
        tokenStart: token?.substring(0, 20) + '...',
      });
      
      if (!token) {
        console.error('❌ No token received from refreshToken()');
        setError('Failed to authenticate. Please login again.');
        setLoading(false);
        return;
      }

      console.log('✅ Token refreshed, starting stream...');
      console.log('📤 Making request to /api/streams/start');

      const requestBody = {
        title: formData.title.trim(),
        description: formData.description.trim() || null,
      };

      console.log('📦 Request body:', requestBody);
      console.log('🔑 Authorization header:', `Bearer ${token.substring(0, 20)}...`);

      const response = await fetch('/api/streams/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(requestBody),
      });

      console.log('📥 Response status:', response.status);
      console.log('📥 Response ok:', response.ok);

      const data = await response.json();
      console.log('📥 Response data:', data);

      if (data.success) {
        console.log('✅ Stream started successfully:', data.stream.id);
        
        // Store stream credentials
        localStorage.setItem('streamCredentials', JSON.stringify(data.credentials));
        
        // Navigate to broadcaster page
        navigate(`/broadcast/${data.stream.id}`);
      } else {
        console.error('❌ Failed to start stream:', data.message);
        setError(data.message || 'Failed to start stream');
      }
    } catch (err) {
      console.error('❌ Start stream error:', err);
      setError('Failed to connect to server');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <title>Go Live - LiveStream Platform</title>
      <meta name="description" content="Start your live stream and connect with your audience" />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Video className="h-12 w-12 text-primary" />
              <h1 className="text-4xl font-bold">Go Live</h1>
            </div>
            <p className="text-muted-foreground">
              Start your live stream and connect with your audience in real-time
            </p>
          </div>

          {/* Debug Info */}
          <div className="mb-4 p-4 bg-muted rounded-lg text-sm">
            <p className="font-semibold mb-2">🔍 Debug Info:</p>
            <p>User: {user ? '✅ Logged in' : '❌ Not logged in'}</p>
            <p>Email: {user?.email || 'N/A'}</p>
            <p>UID: {user?.uid ? user.uid.substring(0, 10) + '...' : 'N/A'}</p>
            <p>Token in localStorage: {localStorage.getItem('firebaseToken') ? '✅ Present' : '❌ Missing'}</p>
          </div>

          {/* Form */}
          <Card>
            <CardHeader>
              <CardTitle>Stream Details</CardTitle>
              <CardDescription>
                Tell your viewers what your stream is about
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Success Message */}
                {syncSuccess && (
                  <div className="bg-green-500/10 border border-green-500 text-green-700 dark:text-green-400 px-4 py-3 rounded-lg">
                    ✅ User synced successfully! You can now create streams.
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded-lg">
                    <p className="font-semibold mb-2">{error}</p>
                    {error.includes('User not found in database') && (
                      <div className="mt-3">
                        <p className="text-sm mb-2">
                          Your Firebase account needs to be synced to the database.
                        </p>
                        <Button
                          type="button"
                          onClick={handleSyncUser}
                          disabled={syncing}
                          variant="outline"
                          size="sm"
                        >
                          {syncing ? 'Syncing...' : 'Sync User to Database'}
                        </Button>
                      </div>
                    )}
                  </div>
                )}

                {/* Title */}
                <div className="space-y-2">
                  <Label htmlFor="title">
                    Stream Title <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="What are you streaming today?"
                    maxLength={255}
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    {formData.title.length}/255 characters
                  </p>
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Add more details about your stream..."
                    rows={4}
                    maxLength={1000}
                  />
                  <p className="text-sm text-muted-foreground">
                    {formData.description.length}/1000 characters
                  </p>
                </div>

                {/* Info Box */}
                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Before you go live:</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Make sure you have a stable internet connection</li>
                    <li>• Test your camera and microphone</li>
                    <li>• Choose a well-lit location</li>
                    <li>• Be ready to engage with your audience</li>
                  </ul>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  className="w-full"
                  size="lg"
                  disabled={loading || !formData.title.trim()}
                >
                  {loading ? (
                    'Starting Stream...'
                  ) : (
                    <>
                      <Radio className="h-5 w-5 mr-2" />
                      Start Live Stream
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Help Text */}
          <div className="mt-6 text-center text-sm text-muted-foreground">
            <p>
              Need help? Check out our{' '}
              <a href="#" className="text-primary hover:underline">
                streaming guide
              </a>
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
