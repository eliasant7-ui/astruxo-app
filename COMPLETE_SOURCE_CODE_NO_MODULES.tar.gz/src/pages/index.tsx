/**
 * Home page - Live Streams Feed
 * Displays all currently live streams
 */

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Eye, Users, Radio, Search, TrendingUp, Clock } from 'lucide-react';

interface Stream {
  id: number;
  title: string;
  description: string | null;
  thumbnailUrl: string | null;
  viewerCount: number;
  startedAt: string;
  user: {
    id: number;
    username: string;
    displayName: string | null;
    avatarUrl: string | null;
    followerCount: number;
  };
}

export default function HomePage() {
  const [streams, setStreams] = useState<Stream[]>([]);
  const [filteredStreams, setFilteredStreams] = useState<Stream[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'viewers' | 'recent'>('viewers');

  useEffect(() => {
    fetchLiveStreams();
    
    // Refresh every 10 seconds
    const interval = setInterval(fetchLiveStreams, 10000);
    return () => clearInterval(interval);
  }, []);

  // Filter and sort streams
  useEffect(() => {
    let result = [...streams];

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (stream) =>
          stream.title.toLowerCase().includes(query) ||
          stream.user.displayName?.toLowerCase().includes(query) ||
          stream.user.username.toLowerCase().includes(query)
      );
    }

    // Apply sorting
    if (sortBy === 'viewers') {
      result.sort((a, b) => b.viewerCount - a.viewerCount);
    } else if (sortBy === 'recent') {
      result.sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime());
    }

    setFilteredStreams(result);
  }, [streams, searchQuery, sortBy]);

  const fetchLiveStreams = async () => {
    try {
      const response = await fetch('/api/streams/live');
      const data = await response.json();

      if (data.success) {
        setStreams(data.streams);
        setError(null);
      } else {
        setError('Failed to load streams');
      }
    } catch (err) {
      setError('Failed to connect to server');
      console.error('Error fetching streams:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading live streams...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <title>Live Streams - LiveStream Platform</title>
      <meta name="description" content="Watch live streams from creators around the world" />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Radio className="h-8 w-8 text-red-500 animate-pulse" />
            <h1 className="text-4xl font-bold">Live Now</h1>
          </div>
          <p className="text-muted-foreground">
            {filteredStreams.length} {filteredStreams.length === 1 ? 'stream' : 'streams'} 
            {searchQuery ? ' found' : ' currently live'}
          </p>
        </div>

        {/* Search and Filters */}
        {streams.length > 0 && (
          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search streams or streamers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Sort Buttons */}
            <div className="flex gap-2">
              <Button
                variant={sortBy === 'viewers' ? 'default' : 'outline'}
                onClick={() => setSortBy('viewers')}
                className="flex items-center gap-2"
              >
                <TrendingUp className="h-4 w-4" />
                Most Viewers
              </Button>
              <Button
                variant={sortBy === 'recent' ? 'default' : 'outline'}
                onClick={() => setSortBy('recent')}
                className="flex items-center gap-2"
              >
                <Clock className="h-4 w-4" />
                Recently Started
              </Button>
            </div>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Empty State - No Streams */}
        {!loading && streams.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <Radio className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h2 className="text-2xl font-semibold mb-2">No Live Streams</h2>
              <p className="text-muted-foreground mb-6">
                There are no live streams at the moment. Check back soon!
              </p>
              <Button asChild>
                <Link to="/go-live">Start Your First Stream</Link>
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Empty State - No Search Results */}
        {!loading && streams.length > 0 && filteredStreams.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <Search className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h2 className="text-2xl font-semibold mb-2">No Results Found</h2>
              <p className="text-muted-foreground mb-6">
                Try adjusting your search or filters
              </p>
              <Button onClick={() => setSearchQuery('')} variant="outline">
                Clear Search
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Streams Grid */}
        {filteredStreams.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStreams.map((stream) => (
              <Link key={stream.id} to={`/stream/${stream.id}`}>
                <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                  {/* Thumbnail */}
                  <div className="relative aspect-video bg-muted">
                    {stream.thumbnailUrl ? (
                      <img
                        src={stream.thumbnailUrl}
                        alt={stream.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Radio className="h-16 w-16 text-muted-foreground" />
                      </div>
                    )}
                    
                    {/* Live Badge */}
                    <div className="absolute top-3 left-3">
                      <Badge variant="destructive" className="animate-pulse">
                        <Radio className="h-3 w-3 mr-1" />
                        LIVE
                      </Badge>
                    </div>

                    {/* Viewer Count */}
                    <div className="absolute top-3 right-3 bg-black/70 text-white px-2 py-1 rounded text-sm flex items-center gap-1">
                      <Eye className="h-4 w-4" />
                      {stream.viewerCount}
                    </div>
                  </div>

                  {/* Content */}
                  <CardHeader>
                    <CardTitle className="line-clamp-2 group-hover:text-primary transition-colors">
                      {stream.title}
                    </CardTitle>
                  </CardHeader>

                  <CardContent>
                    {/* Streamer Info */}
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={stream.user.avatarUrl || undefined} />
                        <AvatarFallback>
                          {stream.user.displayName?.[0] || stream.user.username[0].toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">
                          {stream.user.displayName || stream.user.username}
                        </p>
                        <p className="text-sm text-muted-foreground flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          {stream.user.followerCount} followers
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
