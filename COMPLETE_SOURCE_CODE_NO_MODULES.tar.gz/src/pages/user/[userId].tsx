/**
 * User Profile Page
 * Display user information, followers, and follow/unfollow button
 */

import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { UserPlus, UserMinus, Radio, Eye, Clock, TrendingUp, Settings } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';

interface User {
  id: number;
  username: string;
  displayName: string | null;
  avatarUrl: string | null;
  bio: string | null;
  followerCount: number;
  followingCount: number;
  isLive: boolean;
  isFollowing: boolean;
}

interface Stream {
  id: number;
  title: string;
  description: string | null;
  status: string;
  viewerCount: number;
  peakViewerCount: number;
  startedAt: string;
  endedAt: string | null;
  duration: number | null;
}

interface StreamStats {
  totalStreams: number;
  totalViewers: number;
  totalDuration: number;
  averageViewers: number;
}

export default function UserProfilePage() {
  const { userId } = useParams<{ userId: string }>();
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [streams, setStreams] = useState<Stream[]>([]);
  const [stats, setStats] = useState<StreamStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  
  // Check if viewing own profile
  const isOwnProfile = currentUser?.uid === userId;

  useEffect(() => {
    if (userId) {
      fetchUser();
      fetchUserStreams();
    }
  }, [userId]);

  const fetchUser = async () => {
    try {
      const response = await fetch(`/api/users/${userId}`);
      const data = await response.json();

      if (data.success) {
        setUser(data.user);
        setError(null);
      } else {
        setError('User not found');
      }
    } catch (err) {
      setError('Failed to load user');
      console.error('Error fetching user:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserStreams = async () => {
    try {
      const response = await fetch(`/api/users/${userId}/streams`);
      const data = await response.json();

      if (data.success) {
        setStreams(data.streams);
        setStats(data.stats);
      }
    } catch (err) {
      console.error('Error fetching user streams:', err);
    }
  };

  const formatDuration = (seconds: number | null) => {
    if (!seconds) return '0:00';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const handleFollow = async () => {
    if (!user) return;

    setActionLoading(true);
    try {
      const token = localStorage.getItem('firebaseToken');
      if (!token) {
        alert('Please login to follow users');
        return;
      }

      const endpoint = user.isFollowing
        ? `/api/users/${user.id}/unfollow`
        : `/api/users/${user.id}/follow`;

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (data.success) {
        // Update local state
        setUser({
          ...user,
          isFollowing: !user.isFollowing,
          followerCount: user.isFollowing ? user.followerCount - 1 : user.followerCount + 1,
        });
      } else {
        alert(data.message || 'Failed to update follow status');
      }
    } catch (err) {
      console.error('Follow error:', err);
      alert('Failed to update follow status');
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading profile...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="text-center py-12">
          <CardContent>
            <h2 className="text-2xl font-semibold mb-2">User Not Found</h2>
            <p className="text-muted-foreground">{error || 'This user does not exist'}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <title>{user.displayName || user.username} - LiveStream Platform</title>
      <meta name="description" content={user.bio || `Profile of ${user.displayName || user.username}`} />

      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
              {/* Avatar */}
              <Avatar className="h-32 w-32">
                <AvatarImage src={user.avatarUrl || undefined} />
                <AvatarFallback className="text-4xl">
                  {user.displayName?.[0] || user.username[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>

              {/* User Info */}
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-3xl font-bold">{user.displayName || user.username}</h1>
                  {user.isLive && (
                    <Badge variant="destructive" className="animate-pulse">
                      <Radio className="h-3 w-3 mr-1" />
                      LIVE
                    </Badge>
                  )}
                </div>
                <p className="text-muted-foreground mb-4">@{user.username}</p>

                {/* Stats */}
                <div className="flex gap-6 mb-4">
                  <div>
                    <p className="text-2xl font-bold">{user.followerCount}</p>
                    <p className="text-sm text-muted-foreground">Followers</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{user.followingCount}</p>
                    <p className="text-sm text-muted-foreground">Following</p>
                  </div>
                </div>

                {/* Action Button */}
                {isOwnProfile ? (
                  <Button
                    onClick={() => navigate('/profile/edit')}
                    variant="outline"
                    className="w-full md:w-auto"
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Button>
                ) : (
                  <Button
                    onClick={handleFollow}
                    disabled={actionLoading}
                    variant={user.isFollowing ? 'outline' : 'default'}
                    className="w-full md:w-auto"
                  >
                    {actionLoading ? (
                      'Loading...'
                    ) : user.isFollowing ? (
                      <>
                        <UserMinus className="h-4 w-4 mr-2" />
                        Unfollow
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4 mr-2" />
                        Follow
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>

          {user.bio && (
            <CardContent>
              <h2 className="font-semibold mb-2">About</h2>
              <p className="text-muted-foreground whitespace-pre-wrap">{user.bio}</p>
            </CardContent>
          )}
        </Card>

        {/* Statistics */}
        {stats && stats.totalStreams > 0 && (
          <Card className="max-w-4xl mx-auto mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Channel Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-secondary rounded-lg">
                  <p className="text-3xl font-bold">{stats.totalStreams}</p>
                  <p className="text-sm text-muted-foreground">Total Streams</p>
                </div>
                <div className="text-center p-4 bg-secondary rounded-lg">
                  <p className="text-3xl font-bold">{stats.totalViewers}</p>
                  <p className="text-sm text-muted-foreground">Total Views</p>
                </div>
                <div className="text-center p-4 bg-secondary rounded-lg">
                  <p className="text-3xl font-bold">{stats.averageViewers}</p>
                  <p className="text-sm text-muted-foreground">Avg Viewers</p>
                </div>
                <div className="text-center p-4 bg-secondary rounded-lg">
                  <p className="text-3xl font-bold">{formatDuration(stats.totalDuration)}</p>
                  <p className="text-sm text-muted-foreground">Total Time</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Past Streams */}
        {streams.length > 0 && (
          <Card className="max-w-4xl mx-auto mt-6">
            <CardHeader>
              <CardTitle>Past Streams</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {streams.map((stream) => (
                  <Link
                    key={stream.id}
                    to={`/stream/${stream.id}`}
                    className="block p-4 border rounded-lg hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{stream.title}</h3>
                        {stream.description && (
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                            {stream.description}
                          </p>
                        )}
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            <span>{stream.peakViewerCount} peak viewers</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            <span>{formatDuration(stream.duration)}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={stream.status === 'live' ? 'destructive' : 'secondary'}>
                          {stream.status === 'live' ? (
                            <>
                              <Radio className="h-3 w-3 mr-1 animate-pulse" />
                              LIVE
                            </>
                          ) : (
                            'Ended'
                          )}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-2">
                          {new Date(stream.startedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </>
  );
}
