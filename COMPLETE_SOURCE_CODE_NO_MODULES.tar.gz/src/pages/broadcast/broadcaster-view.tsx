/**
 * Broadcaster View Component
 * Agora video integration for host
 */

import { useEffect, useRef, useState } from 'react';
import AgoraRTC, {
  IAgoraRTCClient,
  ICameraVideoTrack,
  IMicrophoneAudioTrack,
} from 'agora-rtc-sdk-ng';
import { Button } from '@/components/ui/button';
import { Mic, MicOff, Video, VideoOff, AlertCircle } from 'lucide-react';

interface BroadcasterViewProps {
  credentials: {
    appId: string;
    channelName: string;
    token: string;
    uid: number;
  };
  onError?: (error: string) => void;
}

export default function BroadcasterView({ credentials, onError }: BroadcasterViewProps) {
  const [isJoined, setIsJoined] = useState(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isPublishing, setIsPublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const clientRef = useRef<IAgoraRTCClient | null>(null);
  const audioTrackRef = useRef<IMicrophoneAudioTrack | null>(null);
  const videoTrackRef = useRef<ICameraVideoTrack | null>(null);
  const videoContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    joinChannel();

    return () => {
      leaveChannel();
    };
  }, []);

  const joinChannel = async () => {
    try {
      setError(null);

      console.log('🎥 Step 1: Creating Agora client...');
      // Create Agora client with optimized settings
      const client = AgoraRTC.createClient({
        mode: 'live',
        codec: 'vp8',
        role: 'host',
      });
      
      // Enable dual stream for better quality adaptation
      client.enableDualStream();
      
      clientRef.current = client;

      console.log('🎥 Step 2: Setting client role to host...');
      // Set client role to host
      await client.setClientRole('host');

      console.log('🎥 Step 3: Joining Agora channel:', {
        appId: credentials.appId,
        channel: credentials.channelName,
        uid: credentials.uid,
      });

      // Join the channel
      await client.join(
        credentials.appId,
        credentials.channelName,
        credentials.token,
        credentials.uid
      );

      console.log('✅ Joined Agora channel');

      console.log('🎥 Step 4: Requesting camera and microphone access...');
      // Create and publish audio/video tracks
      const [audioTrack, videoTrack] = await AgoraRTC.createMicrophoneAndCameraTracks(
        {
          // Audio config - high quality for clear voice
          encoderConfig: 'music_standard', // 48kHz stereo
          AEC: true, // Acoustic Echo Cancellation
          ANS: true, // Automatic Noise Suppression
          AGC: true, // Automatic Gain Control
        },
        {
          // Video config - optimized for quality and latency
          encoderConfig: {
            width: { ideal: 1280, max: 1920 },
            height: { ideal: 720, max: 1080 },
            frameRate: 30,
            bitrateMin: 800,
            bitrateMax: 1500,
          },
          optimizationMode: 'detail', // Better for static scenes
        }
      );

      audioTrackRef.current = audioTrack;
      videoTrackRef.current = videoTrack;

      console.log('✅ Created audio and video tracks');

      console.log('🎥 Step 5: Playing video locally...');
      // Play video locally
      if (videoContainerRef.current) {
        videoTrack.play(videoContainerRef.current);
      }

      console.log('🎥 Step 6: Publishing tracks to Agora...');
      // Publish tracks
      await client.publish([audioTrack, videoTrack]);

      setIsJoined(true);
      setIsPublishing(true);
      console.log('✅ Successfully published to Agora channel');
    } catch (err) {
      console.error('❌ Failed to join Agora channel:', err);
      
      // More detailed error messages
      let errorMsg = 'Failed to start video';
      if (err instanceof Error) {
        errorMsg = err.message;
        
        // Specific error messages for common issues
        if (err.message.includes('Permission denied') || err.message.includes('NotAllowedError')) {
          errorMsg = 'Camera/microphone access denied. Please allow permissions and try again.';
        } else if (err.message.includes('NotFoundError')) {
          errorMsg = 'No camera or microphone found. Please connect a device and try again.';
        } else if (err.message.includes('NotReadableError')) {
          errorMsg = 'Camera is already in use by another application.';
        } else if (err.message.includes('INVALID_PARAMS')) {
          errorMsg = 'Invalid stream parameters. Please try creating a new stream.';
        }
      }
      
      setError(errorMsg);
      onError?.(errorMsg);
    }
  };

  const leaveChannel = async () => {
    try {
      // Stop and close tracks
      if (audioTrackRef.current) {
        audioTrackRef.current.stop();
        audioTrackRef.current.close();
        audioTrackRef.current = null;
      }

      if (videoTrackRef.current) {
        videoTrackRef.current.stop();
        videoTrackRef.current.close();
        videoTrackRef.current = null;
      }

      // Leave channel
      if (clientRef.current) {
        await clientRef.current.leave();
        clientRef.current = null;
      }

      setIsJoined(false);
      setIsPublishing(false);
      console.log('✅ Left Agora channel');
    } catch (err) {
      console.error('❌ Error leaving channel:', err);
    }
  };

  const toggleMic = async () => {
    if (audioTrackRef.current) {
      await audioTrackRef.current.setEnabled(!isMicOn);
      setIsMicOn(!isMicOn);
    }
  };

  const toggleCamera = async () => {
    if (videoTrackRef.current) {
      await videoTrackRef.current.setEnabled(!isCameraOn);
      setIsCameraOn(!isCameraOn);
    }
  };

  return (
    <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
      {/* Video container */}
      <div
        ref={videoContainerRef}
        className="absolute inset-0"
        style={{ width: '100%', height: '100%' }}
      />

      {/* Loading overlay */}
      {!isPublishing && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="text-center text-white">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
            <p>Connecting to stream...</p>
          </div>
        </div>
      )}

      {/* Error overlay */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80">
          <div className="text-center text-white max-w-md px-4">
            <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <p className="font-semibold mb-2">Connection Error</p>
            <p className="text-sm text-gray-300">{error}</p>
            <Button
              variant="secondary"
              className="mt-4"
              onClick={() => {
                setError(null);
                joinChannel();
              }}
            >
              Retry Connection
            </Button>
          </div>
        </div>
      )}

      {/* Controls overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
        <div className="flex items-center justify-center gap-4">
          <Button
            variant={isMicOn ? 'secondary' : 'destructive'}
            size="icon"
            onClick={toggleMic}
            disabled={!isJoined}
            className="h-12 w-12"
          >
            {isMicOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
          </Button>

          <Button
            variant={isCameraOn ? 'secondary' : 'destructive'}
            size="icon"
            onClick={toggleCamera}
            disabled={!isJoined}
            className="h-12 w-12"
          >
            {isCameraOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Status indicator */}
      <div className="absolute top-4 left-4">
        <div className="flex items-center gap-2 bg-black/50 px-3 py-1.5 rounded-full">
          <div
            className={`h-2 w-2 rounded-full ${
              isPublishing ? 'bg-green-500' : 'bg-yellow-500'
            } animate-pulse`}
          />
          <span className="text-white text-sm font-medium">
            {isPublishing ? 'Broadcasting' : 'Connecting...'}
          </span>
        </div>
      </div>
    </div>
  );
}
