/**
 * Broadcaster Page
 * Interface for streamers to broadcast and manage their live stream
 */

import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Eye, Radio, StopCircle, Users, AlertCircle, Clock, TrendingUp, Send, MessageCircle } from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { toast } from 'sonner';
import BroadcasterView from './broadcaster-view';
import GiftAnimation from '@/components/GiftAnimation';
import { useAuth } from '@/lib/auth-context';

interface ChatMessage {
  id: number;
  userId: number;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  message: string;
  createdAt: string;
  type?: 'join' | 'leave' | 'message';
  isHost?: boolean;
}

export default function BroadcasterPage() {
  const { streamId } = useParams<{ streamId: string }>();
  const navigate = useNavigate();
  const { refreshToken, user } = useAuth();
  const [stream, setStream] = useState<any>(null);
  const [credentials, setCredentials] = useState<any>(null);
  const [viewerCount, setViewerCount] = useState(0);
  const [peakViewerCount, setPeakViewerCount] = useState(0);
  const [streamDuration, setStreamDuration] = useState('0:00');
  const [isEnding, setIsEnding] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Chat state
  const [socket, setSocket] = useState<Socket | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [messageInput, setMessageInput] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [giftNotifications, setGiftNotifications] = useState<any[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchStreamDetails();

    // Poll for viewer count every 5 seconds
    const interval = setInterval(() => {
      fetchStreamDetails();
    }, 5000);

    return () => clearInterval(interval);
  }, [streamId]);

  // Calculate stream duration
  useEffect(() => {
    if (!stream || stream.status !== 'live') return;

    const updateDuration = () => {
      const startTime = new Date(stream.startedAt).getTime();
      const now = Date.now();
      const diff = Math.floor((now - startTime) / 1000); // seconds
      
      const hours = Math.floor(diff / 3600);
      const minutes = Math.floor((diff % 3600) / 60);
      const seconds = diff % 60;
      
      if (hours > 0) {
        setStreamDuration(`${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
      } else {
        setStreamDuration(`${minutes}:${seconds.toString().padStart(2, '0')}`);
      }
    };

    updateDuration();
    const interval = setInterval(updateDuration, 1000);

    return () => clearInterval(interval);
  }, [stream]);

  // Socket.IO connection for chat
  useEffect(() => {
    if (!streamId || !user) return;

    const token = localStorage.getItem('firebaseToken');
    if (!token) return;

    console.log('🔌 Connecting to Socket.IO as broadcaster...');

    const newSocket = io(window.location.origin, {
      auth: { token },
      transports: ['websocket', 'polling'],
    });

    newSocket.on('connect', () => {
      console.log('✅ Socket connected as broadcaster');
      setIsConnected(true);
      
      // Authenticate first
      const token = localStorage.getItem('firebaseToken');
      if (token) {
        console.log('🔐 Authenticating broadcaster with token...');
        newSocket.emit('authenticate', { token });
      }
      
      // Join stream room
      newSocket.emit('join_stream', { streamId: parseInt(streamId) });
    });

    newSocket.on('disconnect', () => {
      console.log('❌ Socket disconnected');
      setIsConnected(false);
    });

    newSocket.on('authenticated', (data: any) => {
      console.log('✅ Broadcaster authenticated:', data);
    });

    newSocket.on('auth_error', (data: { message: string }) => {
      console.error('❌ Authentication error:', data.message);
    });

    newSocket.on('chat_history', (history: ChatMessage[]) => {
      console.log('📜 Received chat history:', history.length, 'messages');
      setMessages(history.map(msg => ({
        ...msg,
        isHost: msg.userId === stream?.userId,
      })));
    });

    newSocket.on('new_message', (message: ChatMessage) => {
      console.log('💬 New message:', message);
      setMessages((prev) => {
        const newMessages = [...prev, {
          ...message,
          isHost: message.userId === stream?.userId,
        }];
        return newMessages.slice(-100);
      });
    });

    newSocket.on('user_joined', (data: { username: string; displayName: string }) => {
      const systemMessage: ChatMessage = {
        id: Date.now(),
        userId: 0,
        username: 'System',
        displayName: 'System',
        avatarUrl: null,
        message: `${data.displayName} joined the stream`,
        createdAt: new Date().toISOString(),
        type: 'join',
      };
      setMessages((prev) => {
        const newMessages = [...prev, systemMessage];
        return newMessages.slice(-100);
      });
    });

    newSocket.on('user_left', (data: { username: string; displayName: string }) => {
      const systemMessage: ChatMessage = {
        id: Date.now(),
        userId: 0,
        username: 'System',
        displayName: 'System',
        avatarUrl: null,
        message: `${data.displayName} left the stream`,
        createdAt: new Date().toISOString(),
        type: 'leave',
      };
      setMessages((prev) => {
        const newMessages = [...prev, systemMessage];
        return newMessages.slice(-100);
      });
    });

    newSocket.on('gift_sent', (data: any) => {
      console.log('🎁 Gift received:', data);
      
      // Show toast notification
      toast.success(`${data.senderDisplayName} sent ${data.giftName}!`, {
        description: `${data.coinAmount} coins${data.message ? ` - "${data.message}"` : ''}`,
        duration: 4000,
      });
      
      // Add to gift notifications (show animation for 5 seconds)
      const notificationId = `gift-${Date.now()}`;
      setGiftNotifications((prev) => [...prev, { ...data, id: notificationId }]);
      
      // Remove notification after 5 seconds
      setTimeout(() => {
        setGiftNotifications((prev) => prev.filter((n) => n.id !== notificationId));
      }, 5000);
      
      // Add system message to chat
      const giftMessage: ChatMessage = {
        id: Date.now(),
        userId: 0,
        username: 'System',
        displayName: 'System',
        avatarUrl: null,
        message: `🎁 ${data.senderDisplayName} sent ${data.giftName} (${data.coinAmount} coins)${data.message ? `: "${data.message}"` : ''}`,
        createdAt: new Date().toISOString(),
        type: 'join',
      };
      setMessages((prev) => {
        const newMessages = [...prev, giftMessage];
        return newMessages.slice(-100);
      });
    });

    newSocket.on('error', (data: { message: string }) => {
      console.error('Socket error:', data.message);
    });

    setSocket(newSocket);

    return () => {
      console.log('🔌 Disconnecting socket...');
      newSocket.disconnect();
    };
  }, [streamId, user, stream?.userId]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const fetchStreamDetails = async () => {
    try {
      const token = localStorage.getItem('firebaseToken');
      const response = await fetch(`/api/streams/${streamId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to fetch stream');
      }

      if (data.success) {
        setStream(data.stream);
        setViewerCount(data.stream.viewerCount || 0);
        setPeakViewerCount(data.stream.peakViewerCount || 0);

        // Set credentials if available
        if (data.credentials) {
          setCredentials(data.credentials);
        }
      }
    } catch (err) {
      console.error('Failed to fetch stream:', err);
      setError(err instanceof Error ? err.message : 'Failed to load stream');
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!messageInput.trim() || !socket || !isConnected) return;

    socket.emit('send_message', {
      streamId: parseInt(streamId!),
      message: messageInput.trim(),
    });

    setMessageInput('');
  };

  const handleEndStream = async () => {
    if (!confirm('Are you sure you want to end this stream?')) {
      return;
    }

    setIsEnding(true);

    try {
      // Refresh token to ensure it's valid
      console.log('🔄 Refreshing token before ending stream...');
      const token = await refreshToken();
      
      if (!token) {
        console.error('❌ No token received from refreshToken()');
        setError('Failed to authenticate. Please login again.');
        setIsEnding(false);
        return;
      }

      console.log('✅ Token refreshed, ending stream...');
      console.log('📤 Making request to /api/streams/' + streamId + '/end');
      
      const response = await fetch(`/api/streams/${streamId}/end`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });

      console.log('📥 Response status:', response.status);
      const data = await response.json();
      console.log('📥 Response data:', data);

      if (data.success) {
        console.log('✅ Stream ended successfully');
        // Clear credentials
        localStorage.removeItem('streamCredentials');
        
        // Navigate to home
        navigate('/');
      } else {
        console.error('❌ Failed to end stream:', data.message);
        setError(data.message || 'Failed to end stream');
      }
    } catch (err) {
      console.error('❌ End stream error:', err);
      setError(err instanceof Error ? err.message : 'Failed to end stream');
    } finally {
      setIsEnding(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading stream...</p>
        </div>
      </div>
    );
  }

  if (!stream || !credentials) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Stream Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">
              This stream does not exist or has ended.
            </p>
            <Button onClick={() => navigate('/')}>Go Home</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <title>Broadcasting - {stream.title}</title>
      <meta name="description" content={`Live streaming: ${stream.title}`} />

      <div className="container mx-auto px-4 py-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Badge variant="destructive" className="animate-pulse">
              <Radio className="h-3 w-3 mr-1" />
              LIVE
            </Badge>
            <h1 className="text-2xl font-bold">{stream.title}</h1>
          </div>

          <Button
            variant="destructive"
            size="lg"
            onClick={handleEndStream}
            disabled={isEnding}
          >
            {isEnding ? (
              'Ending...'
            ) : (
              <>
                <StopCircle className="h-5 w-5 mr-2" />
                End Stream
              </>
            )}
          </Button>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded-lg mb-4 flex items-start gap-2">
            <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold">Error</p>
              <p className="text-sm">{error}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Main Broadcast View */}
          <div className="lg:col-span-2 space-y-4">
            {/* Video Container */}
            <Card className="overflow-hidden">
              <BroadcasterView
                credentials={credentials}
                onError={(err) => setError(err)}
              />
            </Card>

            {/* Stream Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Stream Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                {stream.description && (
                  <div>
                    <span className="text-muted-foreground">Description:</span>
                    <p>{stream.description}</p>
                  </div>
                )}
                <div>
                  <span className="text-muted-foreground">Channel ID:</span>
                  <p className="font-mono text-xs break-all">{stream.agoraChannelId}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Started:</span>
                  <p>{new Date(stream.startedAt).toLocaleString()}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar - Stats & Chat */}
          <div className="lg:col-span-2 space-y-4">
            {/* Stats Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Live Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  {/* Duration */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span className="text-xs">Duration</span>
                    </div>
                    <div className="text-xl font-bold tabular-nums">{streamDuration}</div>
                  </div>

                  {/* Current Viewers */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Eye className="h-3 w-3" />
                      <span className="text-xs">Watching</span>
                    </div>
                    <div className="text-xl font-bold text-primary">{viewerCount}</div>
                  </div>

                  {/* Peak Viewers */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Users className="h-3 w-3" />
                      <span className="text-xs">Peak</span>
                    </div>
                    <div className="text-xl font-bold">{peakViewerCount}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Live Chat */}
            <Card className="flex flex-col h-[600px]">
              <CardHeader className="border-b">
                <CardTitle className="text-lg flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Live Chat
                  </div>
                  <Badge variant={isConnected ? 'default' : 'secondary'} className="text-xs">
                    {isConnected ? '✓ Connected' : 'Connecting...'}
                  </Badge>
                </CardTitle>
              </CardHeader>

              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-3">
                  {messages.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <MessageCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No messages yet</p>
                      <p className="text-xs">Be the first to say hello!</p>
                    </div>
                  ) : (
                    messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex gap-2 ${msg.type ? 'justify-center' : ''}`}
                      >
                        {msg.type ? (
                          // System message
                          <div className="text-xs text-muted-foreground italic text-center">
                            {msg.message}
                          </div>
                        ) : (
                          // User message
                          <>
                            <Avatar className="h-8 w-8 flex-shrink-0">
                              <AvatarImage src={msg.avatarUrl || undefined} />
                              <AvatarFallback>
                                {msg.displayName?.[0] || msg.username[0].toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className={`text-sm font-semibold ${msg.isHost ? 'text-primary' : ''}`}>
                                  {msg.displayName || msg.username}
                                </span>
                                {msg.isHost && (
                                  <Badge variant="default" className="text-xs px-1 py-0">
                                    HOST
                                  </Badge>
                                )}
                                <span className="text-xs text-muted-foreground">
                                  {new Date(msg.createdAt).toLocaleTimeString([], {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                                </span>
                              </div>
                              <p className="text-sm break-words">{msg.message}</p>
                            </div>
                          </>
                        )}
                      </div>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              {/* Message Input */}
              <div className="p-4 border-t">
                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <Input
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    placeholder="Send a message as host..."
                    maxLength={500}
                    disabled={!isConnected}
                  />
                  <Button type="submit" size="icon" disabled={!messageInput.trim() || !isConnected}>
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </div>
            </Card>
          </div>
        </div>

        {/* Gift Animations */}
        <GiftAnimation notifications={giftNotifications} />
      </div>
    </>
  );
}
