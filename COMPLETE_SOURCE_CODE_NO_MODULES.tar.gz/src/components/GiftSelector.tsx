/**
 * Gift Selector Component
 * Modal for selecting and sending gifts during live streams
 */

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import {
  Heart,
  ThumbsUp,
  Star,
  Flame,
  Flower2,
  Trophy,
  Crown,
  Gem,
  Rocket,
  Gift,
  Sparkles,
  PartyPopper,
  Zap,
  Sparkle,
  Coins,
  Send,
  Loader2,
} from 'lucide-react';

interface Gift {
  id: number;
  name: string;
  icon: string;
  coinPrice: number;
  animationType: string;
}

interface GiftSelectorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  streamId: number;
  onGiftSent: (gift: Gift, message?: string) => void;
}

// Icon mapping
const ICON_MAP: Record<string, any> = {
  Heart,
  ThumbsUp,
  Star,
  Flame,
  Flower2,
  Trophy,
  Crown,
  Gem,
  Rocket,
  Gift,
  Sparkles,
  PartyPopper,
  Zap,
  Sparkle,
};

export default function GiftSelector({ open, onOpenChange, streamId, onGiftSent }: GiftSelectorProps) {
  const navigate = useNavigate();
  const [gifts, setGifts] = useState<Gift[]>([]);
  const [selectedGift, setSelectedGift] = useState<Gift | null>(null);
  const [message, setMessage] = useState('');
  const [coinBalance, setCoinBalance] = useState(0);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (open) {
      fetchGifts();
      fetchBalance();
    }
  }, [open]);

  const fetchGifts = async () => {
    try {
      const response = await fetch('/api/gifts');
      const data = await response.json();
      if (data.success) {
        setGifts(data.gifts);
      }
    } catch (error) {
      console.error('Error fetching gifts:', error);
    }
  };

  const fetchBalance = async () => {
    try {
      const token = localStorage.getItem('firebaseToken');
      if (!token) return;

      const response = await fetch('/api/wallet/balance', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (data.success) {
        setCoinBalance(data.balance.coins);
      }
    } catch (error) {
      console.error('Error fetching balance:', error);
    }
  };

  const handleSendGift = async () => {
    if (!selectedGift) return;

    setSending(true);
    try {
      const token = localStorage.getItem('firebaseToken');
      if (!token) {
        alert('Please login to send gifts');
        return;
      }

      const response = await fetch('/api/gifts/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          giftId: selectedGift.id,
          streamId,
          message: message.trim() || undefined,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setCoinBalance(data.transaction.newBalance);
        onGiftSent(selectedGift, message.trim() || undefined);
        setSelectedGift(null);
        setMessage('');
        onOpenChange(false);
      } else {
        alert(data.message || 'Failed to send gift');
      }
    } catch (error) {
      console.error('Error sending gift:', error);
      alert('Failed to send gift');
    } finally {
      setSending(false);
    }
  };

  const getGiftIcon = (iconName: string) => {
    const IconComponent = ICON_MAP[iconName] || Gift;
    return IconComponent;
  };

  const getTierColor = (price: number) => {
    if (price >= 1000) return 'text-purple-500';
    if (price >= 100) return 'text-blue-500';
    if (price >= 25) return 'text-yellow-500';
    return 'text-gray-500';
  };

  const getTierBg = (price: number) => {
    if (price >= 1000) return 'bg-purple-500/10 hover:bg-purple-500/20';
    if (price >= 100) return 'bg-blue-500/10 hover:bg-blue-500/20';
    if (price >= 25) return 'bg-yellow-500/10 hover:bg-yellow-500/20';
    return 'bg-secondary hover:bg-secondary/80';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Send a Gift</span>
            <Badge variant="outline" className="flex items-center gap-1">
              <Coins className="h-4 w-4" />
              {coinBalance} coins
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Show your support by sending a gift to the streamer
          </DialogDescription>
        </DialogHeader>

        {/* Selected Gift Preview */}
        {selectedGift && (
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg p-4 border-2 border-primary/20">
            <div className="flex items-center gap-4">
              {(() => {
                const IconComponent = getGiftIcon(selectedGift.icon);
                return <IconComponent className={`h-12 w-12 ${getTierColor(selectedGift.coinPrice)}`} />;
              })()}
              <div className="flex-1">
                <h3 className="font-semibold text-lg">{selectedGift.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {selectedGift.coinPrice >= 1000 ? 'Epic Gift' : 
                   selectedGift.coinPrice >= 100 ? 'Luxury Gift' : 
                   selectedGift.coinPrice >= 25 ? 'Premium Gift' : 'Basic Gift'}
                </p>
              </div>
              <Badge className="text-lg px-3 py-1">
                <Coins className="h-5 w-5 mr-2" />
                {selectedGift.coinPrice}
              </Badge>
            </div>
          </div>
        )}

        <ScrollArea className="max-h-[350px] pr-4">
          {/* Gift Grid */}
          <div className="grid grid-cols-4 gap-3">
            {gifts.map((gift) => {
              const IconComponent = getGiftIcon(gift.icon);
              const isSelected = selectedGift?.id === gift.id;
              const canAfford = coinBalance >= gift.coinPrice;

              return (
                <button
                  key={gift.id}
                  onClick={() => setSelectedGift(gift)}
                  disabled={!canAfford}
                  className={`
                    relative p-4 rounded-lg border-2 transition-all duration-200
                    ${isSelected ? 'border-primary scale-105 shadow-lg' : 'border-transparent'}
                    ${getTierBg(gift.coinPrice)}
                    ${!canAfford ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:scale-105'}
                  `}
                >
                  {isSelected && (
                    <div className="absolute -top-1 -right-1 bg-primary text-primary-foreground rounded-full p-1">
                      <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                  )}
                  <div className="flex flex-col items-center gap-2">
                    <IconComponent className={`h-8 w-8 ${getTierColor(gift.coinPrice)} transition-transform ${isSelected ? 'scale-110' : ''}`} />
                    <span className="text-xs font-medium text-center">{gift.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      <Coins className="h-3 w-3 mr-1" />
                      {gift.coinPrice}
                    </Badge>
                  </div>
                </button>
              );
            })}
          </div>
        </ScrollArea>

        {/* Selected Gift Details */}
        {selectedGift && (
          <div className="space-y-4 pt-4 border-t">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {(() => {
                  const IconComponent = getGiftIcon(selectedGift.icon);
                  return <IconComponent className={`h-6 w-6 ${getTierColor(selectedGift.coinPrice)}`} />;
                })()}
                <div>
                  <p className="font-semibold">{selectedGift.name}</p>
                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                    <Coins className="h-3 w-3" />
                    {selectedGift.coinPrice} coins
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setSelectedGift(null)}>
                Change
              </Button>
            </div>

            <Textarea
              placeholder="Add a message (optional)"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              maxLength={200}
              rows={2}
            />

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={handleSendGift}
                disabled={sending || coinBalance < selectedGift.coinPrice}
                className="flex-1"
              >
                {sending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Send Gift
                  </>
                )}
              </Button>
            </div>

            {coinBalance < selectedGift.coinPrice && (
              <p className="text-sm text-destructive text-center">
                Insufficient coins. You need {selectedGift.coinPrice - coinBalance} more coins.
              </p>
            )}
          </div>
        )}

        {/* Buy Coins CTA */}
        {coinBalance < 100 && (
          <div className="text-center p-4 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground mb-2">Need more coins?</p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                onOpenChange(false);
                navigate('/buy-coins');
              }}
            >
              <Coins className="h-4 w-4 mr-2" />
              Buy Coins
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
