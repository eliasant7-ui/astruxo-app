import { createBrowserRouter, RouterProvider, Outlet } from 'react-router-dom';
import { Suspense } from 'react';
import AiroErrorBoundary from '../dev-tools/src/AiroErrorBoundary';
import RootLayout from './layouts/RootLayout';
import { routes } from './routes';
import Spinner from './components/Spinner';
import { AuthProvider } from './lib/auth-context';

const SpinnerFallback = () => (
  <div className="flex justify-center py-8 h-screen items-center">
    <Spinner />
  </div>
);

// Create router with layout wrapper
const router = createBrowserRouter([
  {
    path: '/',
    element: import.meta.env.MODE === 'development' ? (
      <AiroErrorBoundary>
        <AuthProvider>
          <Suspense fallback={<SpinnerFallback />}>
            <RootLayout>
              <Outlet />
            </RootLayout>
          </Suspense>
        </AuthProvider>
      </AiroErrorBoundary>
    ) : (
      <AuthProvider>
        <Suspense fallback={<SpinnerFallback />}>
          <RootLayout>
            <Outlet />
          </RootLayout>
        </Suspense>
      </AuthProvider>
    ),
    children: routes,
  },
]);

export default function App() {
  return <RouterProvider router={router} />;
}
