/**
 * Socket.IO Service for Real-time Chat
 * Handles WebSocket connections for live stream chat
 */

import { Server as SocketIOServer } from 'socket.io';
import type { Server as HTTPServer } from 'http';
import { verifyFirebaseToken } from './firebase.js';
import { db } from '../db/client.js';
import { users, chatMessages, streams } from '../db/schema.js';
import { eq } from 'drizzle-orm';

let io: SocketIOServer | null = null;

interface ChatMessage {
  id: number;
  streamId: number;
  userId: number;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  message: string;
  createdAt: Date;
}

/**
 * Initialize Socket.IO server
 */
export function initializeSocketIO(httpServer: HTTPServer) {
  console.log('🔌 Initializing Socket.IO server...');
  
  if (!httpServer) {
    console.error('❌ HTTP server is null or undefined!');
    return null;
  }

  try {
    io = new SocketIOServer(httpServer, {
      cors: {
        origin: '*', // Allow all origins for now (can be restricted later)
        methods: ['GET', 'POST'],
        credentials: true,
      },
      path: '/socket.io',
      transports: ['websocket', 'polling'], // Support both transports
      allowEIO3: true, // Support older clients
    });

    console.log('✅ Socket.IO server created successfully');

    io.on('connection', (socket) => {
      console.log(`✅ Socket connected: ${socket.id}`);

    // Handle authentication
    socket.on('authenticate', async (data: { token: string }) => {
      try {
        const decodedToken = await verifyFirebaseToken(data.token);
        if (!decodedToken) {
          socket.emit('auth_error', { message: 'Invalid token' });
          return;
        }

        // Load user from database
        const userResult = await db
          .select()
          .from(users)
          .where(eq(users.firebaseUid, decodedToken.uid))
          .limit(1);

        if (userResult.length === 0) {
          socket.emit('auth_error', { message: 'User not found' });
          return;
        }

        const user = userResult[0];
        (socket as any).userId = user.id;
        (socket as any).username = user.username;
        (socket as any).displayName = user.displayName;
        (socket as any).avatarUrl = user.avatarUrl;

        socket.emit('authenticated', { userId: user.id, username: user.username });
        console.log(`🔐 User authenticated: ${user.username} (${socket.id})`);
      } catch (error) {
        console.error('Authentication error:', error);
        socket.emit('auth_error', { message: 'Authentication failed' });
      }
    });

    // Join stream room
    socket.on('join_stream', async (data: { streamId: number }) => {
      try {
        const { streamId } = data;

        // Verify stream exists and is live
        const streamResult = await db.select().from(streams).where(eq(streams.id, streamId)).limit(1);

        if (streamResult.length === 0) {
          socket.emit('error', { message: 'Stream not found' });
          return;
        }

        const stream = streamResult[0];

        if (stream.status !== 'live') {
          socket.emit('error', { message: 'Stream is not live' });
          return;
        }

        // Join room
        const roomName = `stream_${streamId}`;
        socket.join(roomName);
        (socket as any).currentStreamId = streamId;

        socket.emit('joined_stream', { streamId, roomName });
        console.log(`📺 User joined stream ${streamId} (${socket.id})`);

        // Load and send chat history (last 50 messages)
        const history = await db
          .select({
            id: chatMessages.id,
            streamId: chatMessages.streamId,
            userId: chatMessages.userId,
            username: users.username,
            displayName: users.displayName,
            avatarUrl: users.avatarUrl,
            message: chatMessages.message,
            createdAt: chatMessages.createdAt,
          })
          .from(chatMessages)
          .innerJoin(users, eq(chatMessages.userId, users.id))
          .where(eq(chatMessages.streamId, streamId))
          .orderBy(chatMessages.createdAt)
          .limit(50);

        socket.emit('chat_history', history);
        console.log(`📜 Sent ${history.length} chat messages to ${socket.id}`);

        // Update viewer count
        const roomSize = io?.sockets.adapter.rooms.get(roomName)?.size || 0;
        await db
          .update(streams)
          .set({
            viewerCount: roomSize,
            peakViewerCount: Math.max(stream.peakViewerCount, roomSize),
          })
          .where(eq(streams.id, streamId));

        // Broadcast viewer count update
        io?.to(roomName).emit('viewer_count', { count: roomSize });
        
        // Broadcast user joined notification (only if authenticated)
        if ((socket as any).userId) {
          io?.to(roomName).emit('user_joined', {
            username: (socket as any).username,
            displayName: (socket as any).displayName || (socket as any).username,
          });
        }
      } catch (error) {
        console.error('Join stream error:', error);
        socket.emit('error', { message: 'Failed to join stream' });
      }
    });

    // Leave stream room
    socket.on('leave_stream', async (data: { streamId: number }) => {
      try {
        const { streamId } = data;
        const roomName = `stream_${streamId}`;

        socket.leave(roomName);
        
        // Broadcast user left notification (only if authenticated)
        if ((socket as any).userId) {
          io?.to(roomName).emit('user_left', {
            username: (socket as any).username,
            displayName: (socket as any).displayName || (socket as any).username,
          });
        }
        
        (socket as any).currentStreamId = null;

        // Update viewer count
        const roomSize = io?.sockets.adapter.rooms.get(roomName)?.size || 0;
        await db.update(streams).set({ viewerCount: roomSize }).where(eq(streams.id, streamId));

        // Broadcast viewer count update
        io?.to(roomName).emit('viewer_count', { count: roomSize });

        console.log(`👋 User left stream ${streamId} (${socket.id})`);
      } catch (error) {
        console.error('Leave stream error:', error);
      }
    });

    // Send chat message
    socket.on('send_message', async (data: { streamId: number; message: string }) => {
      try {
        const userId = (socket as any).userId;
        const username = (socket as any).username;
        const displayName = (socket as any).displayName;
        const avatarUrl = (socket as any).avatarUrl;

        if (!userId) {
          socket.emit('error', { message: 'Not authenticated' });
          return;
        }

        const { streamId, message } = data;

        if (!message || message.trim().length === 0) {
          socket.emit('error', { message: 'Message cannot be empty' });
          return;
        }

        if (message.length > 500) {
          socket.emit('error', { message: 'Message too long (max 500 characters)' });
          return;
        }

        // Save message to database
        const result = await db.insert(chatMessages).values({
          streamId,
          userId,
          message: message.trim(),
        });

        const messageId = Number(result[0].insertId);

        // Broadcast message to room
        const roomName = `stream_${streamId}`;
        const chatMessage: ChatMessage = {
          id: messageId,
          streamId,
          userId,
          username,
          displayName: displayName || username,
          avatarUrl,
          message: message.trim(),
          createdAt: new Date(),
        };

        io?.to(roomName).emit('new_message', chatMessage);
        console.log(`💬 Message sent in stream ${streamId} by ${username}`);
      } catch (error) {
        console.error('Send message error:', error);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // Send gift notification
    socket.on('send_gift', async (data: {
      streamId: number;
      giftName: string;
      giftIcon: string;
      coinAmount: number;
      message?: string;
    }) => {
      try {
        const username = (socket as any).username;
        const displayName = (socket as any).displayName;
        const avatarUrl = (socket as any).avatarUrl;

        const roomName = `stream_${data.streamId}`;
        
        // Broadcast gift notification to all viewers
        io?.to(roomName).emit('gift_sent', {
          senderUsername: username,
          senderDisplayName: displayName || username,
          senderAvatar: avatarUrl,
          giftName: data.giftName,
          giftIcon: data.giftIcon,
          coinAmount: data.coinAmount,
          message: data.message,
          timestamp: new Date(),
        });

        console.log(`🎁 Gift sent in stream ${data.streamId}: ${data.giftName} (${data.coinAmount} coins) by ${username}`);
      } catch (error) {
        console.error('Send gift notification error:', error);
      }
    });

    // Handle disconnect
    socket.on('disconnect', async () => {
      console.log(`❌ Socket disconnected: ${socket.id}`);

      const streamId = (socket as any).currentStreamId;
      if (streamId) {
        const roomName = `stream_${streamId}`;
        const roomSize = io?.sockets.adapter.rooms.get(roomName)?.size || 0;

        // Update viewer count
        await db.update(streams).set({ viewerCount: roomSize }).where(eq(streams.id, streamId));

        // Broadcast viewer count update
        io?.to(roomName).emit('viewer_count', { count: roomSize });
      }
    });
  });

    console.log('✅ Socket.IO initialized and listening for connections');
    return io;
  } catch (error) {
    console.error('❌ Failed to initialize Socket.IO:', error);
    return null;
  }
}

/**
 * Get Socket.IO instance
 */
export function getSocketIO(): SocketIOServer | null {
  return io;
}
