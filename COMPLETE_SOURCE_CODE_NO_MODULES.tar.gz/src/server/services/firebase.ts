/**
 * Firebase Admin SDK Service
 * Handles authentication verification
 */

import admin from 'firebase-admin';
import { getSecret } from '#airo/secrets';

let firebaseApp: admin.app.App | null = null;

/**
 * Initialize Firebase Admin SDK
 */
export function initializeFirebase() {
  // Check if Firebase Admin is already initialized
  if (admin.apps.length > 0) {
    firebaseApp = admin.app();
    console.log('✅ Firebase Admin already initialized, reusing existing app');
    return firebaseApp;
  }

  if (firebaseApp) {
    return firebaseApp;
  }

  try {
    const projectId = getSecret('FIREBASE_PROJECT_ID');
    const privateKeyRaw = getSecret('FIREBASE_PRIVATE_KEY');
    const clientEmail = getSecret('FIREBASE_CLIENT_EMAIL');

    if (!projectId || !privateKeyRaw || !clientEmail) {
      console.warn('Firebase credentials not configured. Auth will not work.');
      return null;
    }

    // Ensure secrets are strings and handle private key formatting
    const projectIdStr = typeof projectId === 'string' ? projectId : String(projectId);
    const clientEmailStr = typeof clientEmail === 'string' ? clientEmail : String(clientEmail);
    
    // Handle private key - it might have escaped newlines or actual newlines
    let privateKey = typeof privateKeyRaw === 'string' ? privateKeyRaw : String(privateKeyRaw);
    
    // If the key has literal \n strings, convert them to actual newlines
    if (privateKey.includes('\\n')) {
      privateKey = privateKey.replace(/\\n/g, '\n');
    }
    
    // Trim any extra whitespace
    privateKey = privateKey.trim();

    firebaseApp = admin.initializeApp({
      credential: admin.credential.cert({
        projectId: projectIdStr,
        privateKey,
        clientEmail: clientEmailStr,
      }),
    });

    console.log('✅ Firebase Admin initialized');
    return firebaseApp;
  } catch (error) {
    console.error('❌ Firebase initialization failed:', error);
    return null;
  }
}

/**
 * Verify Firebase ID token
 */
export async function verifyFirebaseToken(idToken: string): Promise<admin.auth.DecodedIdToken | null> {
  try {
    if (!firebaseApp) {
      console.log('🔄 Firebase not initialized, initializing now...');
      initializeFirebase();
    }

    if (!firebaseApp) {
      console.error('❌ Firebase app is null after initialization');
      throw new Error('Firebase not initialized');
    }

    console.log('🔍 Verifying token with Firebase Admin...');
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    console.log('✅ Token verified successfully:', {
      uid: decodedToken.uid,
      email: decodedToken.email,
    });
    return decodedToken;
  } catch (error) {
    console.error('❌ Token verification failed:', error);
    if (error instanceof Error) {
      console.error('Error details:', error.message);
    }
    return null;
  }
}

/**
 * Get user by Firebase UID
 */
export async function getFirebaseUser(uid: string) {
  try {
    if (!firebaseApp) {
      initializeFirebase();
    }

    if (!firebaseApp) {
      throw new Error('Firebase not initialized');
    }

    const user = await admin.auth().getUser(uid);
    return user;
  } catch (error) {
    console.error('Get user failed:', error);
    return null;
  }
}
