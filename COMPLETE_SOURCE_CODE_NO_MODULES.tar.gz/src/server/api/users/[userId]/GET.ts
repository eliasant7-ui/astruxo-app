/**
 * GET /api/users/:userId
 * Get user profile by ID
 */

import type { Request, Response } from 'express';
import { db } from '../../../db/client.js';
import { users, follows } from '../../../db/schema.js';
import { eq, and } from 'drizzle-orm';
import { optionalAuth } from '../../../middleware/auth.js';

export const middleware = [optionalAuth];

export default async function handler(req: Request, res: Response) {
  try {
    const userIdParam = req.params.userId;
    
    // Try to parse as numeric ID first
    const numericId = parseInt(userIdParam);
    let userResult;

    if (!isNaN(numericId)) {
      // Lookup by database ID
      userResult = await db.select().from(users).where(eq(users.id, numericId)).limit(1);
    } else {
      // Lookup by Firebase UID or username
      userResult = await db
        .select()
        .from(users)
        .where(eq(users.firebaseUid, userIdParam))
        .limit(1);
      
      // If not found by UID, try username
      if (userResult.length === 0) {
        userResult = await db
          .select()
          .from(users)
          .where(eq(users.username, userIdParam))
          .limit(1);
      }
    }

    if (userResult.length === 0) {
      return res.status(404).json({
        error: 'Not Found',
        message: 'User not found',
      });
    }

    const user = userResult[0];

    // Check if current user follows this user
    let isFollowing = false;
    if (req.user) {
      const followResult = await db
        .select()
        .from(follows)
        .where(and(eq(follows.followerId, req.user.id), eq(follows.followingId, user.id)))
        .limit(1);

      isFollowing = followResult.length > 0;
    }

    return res.json({
      success: true,
      user: {
        ...user,
        isFollowing,
      },
    });
  } catch (error) {
    console.error('Get user error:', error);
    return res.status(500).json({
      error: 'Internal Server Error',
      message: 'Failed to get user',
    });
  }
}
