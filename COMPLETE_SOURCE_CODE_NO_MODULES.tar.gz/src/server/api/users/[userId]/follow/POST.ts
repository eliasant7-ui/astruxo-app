/**
 * POST /api/users/:userId/follow
 * Follow a user
 */

import type { Request, Response } from 'express';
import { db } from '../../../../db/client.js';
import { users, follows } from '../../../../db/schema.js';
import { eq, and, sql } from 'drizzle-orm';
import { authenticateUser } from '../../../../middleware/auth.js';

export const middleware = [authenticateUser];

export default async function handler(req: Request, res: Response) {
  try {
    const targetUserId = parseInt(req.params.userId);

    if (isNaN(targetUserId)) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'Invalid user ID',
      });
    }

    if (!req.user) {
      return res.status(401).json({
        error: 'Unauthorized',
        message: 'Authentication required',
      });
    }

    // Can't follow yourself
    if (req.user.id === targetUserId) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'You cannot follow yourself',
      });
    }

    // Check if target user exists
    const targetUser = await db.select().from(users).where(eq(users.id, targetUserId)).limit(1);

    if (targetUser.length === 0) {
      return res.status(404).json({
        error: 'Not Found',
        message: 'User not found',
      });
    }

    // Check if already following
    const existingFollow = await db
      .select()
      .from(follows)
      .where(and(eq(follows.followerId, req.user.id), eq(follows.followingId, targetUserId)))
      .limit(1);

    if (existingFollow.length > 0) {
      return res.status(409).json({
        error: 'Conflict',
        message: 'Already following this user',
      });
    }

    // Create follow relationship
    await db.insert(follows).values({
      followerId: req.user.id,
      followingId: targetUserId,
    });

    // Update follower counts
    await db
      .update(users)
      .set({ followingCount: sql`${users.followingCount} + 1` })
      .where(eq(users.id, req.user.id));

    await db
      .update(users)
      .set({ followerCount: sql`${users.followerCount} + 1` })
      .where(eq(users.id, targetUserId));

    return res.status(201).json({
      success: true,
      message: 'Successfully followed user',
    });
  } catch (error) {
    console.error('Follow user error:', error);
    return res.status(500).json({
      error: 'Internal Server Error',
      message: 'Failed to follow user',
    });
  }
}
