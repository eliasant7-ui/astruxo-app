/**
 * POST /api/users/:userId/unfollow
 * Unfollow a user
 */

import type { Request, Response } from 'express';
import { db } from '../../../../db/client.js';
import { users, follows } from '../../../../db/schema.js';
import { eq, and, sql } from 'drizzle-orm';
import { authenticateUser } from '../../../../middleware/auth.js';

export const middleware = [authenticateUser];

export default async function handler(req: Request, res: Response) {
  try {
    const targetUserId = parseInt(req.params.userId);

    if (isNaN(targetUserId)) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'Invalid user ID',
      });
    }

    if (!req.user) {
      return res.status(401).json({
        error: 'Unauthorized',
        message: 'Authentication required',
      });
    }

    // Check if following
    const existingFollow = await db
      .select()
      .from(follows)
      .where(and(eq(follows.followerId, req.user.id), eq(follows.followingId, targetUserId)))
      .limit(1);

    if (existingFollow.length === 0) {
      return res.status(404).json({
        error: 'Not Found',
        message: 'Not following this user',
      });
    }

    // Delete follow relationship
    await db
      .delete(follows)
      .where(and(eq(follows.followerId, req.user.id), eq(follows.followingId, targetUserId)));

    // Update follower counts
    await db
      .update(users)
      .set({ followingCount: sql`${users.followingCount} - 1` })
      .where(eq(users.id, req.user.id));

    await db
      .update(users)
      .set({ followerCount: sql`${users.followerCount} - 1` })
      .where(eq(users.id, targetUserId));

    return res.json({
      success: true,
      message: 'Successfully unfollowed user',
    });
  } catch (error) {
    console.error('Unfollow user error:', error);
    return res.status(500).json({
      error: 'Internal Server Error',
      message: 'Failed to unfollow user',
    });
  }
}
