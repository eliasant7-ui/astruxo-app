/**
 * GET /api/users/:userId/followers
 * Get list of followers for a user
 */

import type { Request, Response } from 'express';
import { db } from '../../../../db/client.js';
import { users, follows } from '../../../../db/schema.js';
import { eq } from 'drizzle-orm';

export default async function handler(req: Request, res: Response) {
  try {
    const userId = parseInt(req.params.userId);

    if (isNaN(userId)) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'Invalid user ID',
      });
    }

    // Get followers with user details
    const followers = await db
      .select({
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        avatarUrl: users.avatarUrl,
        followerCount: users.followerCount,
        followedAt: follows.createdAt,
      })
      .from(follows)
      .innerJoin(users, eq(follows.followerId, users.id))
      .where(eq(follows.followingId, userId));

    return res.json({
      success: true,
      followers,
      count: followers.length,
    });
  } catch (error) {
    console.error('Get followers error:', error);
    return res.status(500).json({
      error: 'Internal Server Error',
      message: 'Failed to get followers',
    });
  }
}
