/**
 * GET /api/streams/:streamId
 * Get stream details and viewer token
 */

import type { Request, Response } from 'express';
import { db } from '../../../db/client.js';
import { streams, users, follows } from '../../../db/schema.js';
import { eq, and } from 'drizzle-orm';
import { generateAgoraSubscriberToken, getAgoraAppId } from '../../../services/agora.js';
import { optionalAuth } from '../../../middleware/auth.js';

export const middleware = [optionalAuth];

export default async function handler(req: Request, res: Response) {
  try {
    const streamId = parseInt(req.params.streamId);

    if (isNaN(streamId)) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'Invalid stream ID',
      });
    }

    // Get stream with user details
    const streamResult = await db
      .select({
        id: streams.id,
        title: streams.title,
        description: streams.description,
        thumbnailUrl: streams.thumbnailUrl,
        status: streams.status,
        agoraChannelId: streams.agoraChannelId,
        viewerCount: streams.viewerCount,
        peakViewerCount: streams.peakViewerCount,
        totalGiftsReceived: streams.totalGiftsReceived,
        startedAt: streams.startedAt,
        endedAt: streams.endedAt,
        user: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatarUrl: users.avatarUrl,
          followerCount: users.followerCount,
        },
      })
      .from(streams)
      .innerJoin(users, eq(streams.userId, users.id))
      .where(eq(streams.id, streamId))
      .limit(1);

    if (streamResult.length === 0) {
      return res.status(404).json({
        error: 'Not Found',
        message: 'Stream not found',
      });
    }

    const stream = streamResult[0];

    // Check if current user follows the streamer
    let isFollowing = false;
    if (req.user && stream.user.id !== req.user.id) {
      const followResult = await db
        .select()
        .from(follows)
        .where(and(
          eq(follows.followerId, req.user.id),
          eq(follows.followingId, stream.user.id)
        ))
        .limit(1);
      
      isFollowing = followResult.length > 0;
    }

    // Add isFollowing to user object
    const streamWithFollowStatus = {
      ...stream,
      user: {
        ...stream.user,
        isFollowing,
      },
    };

    // Generate viewer token if stream is live
    let credentials = null;
    if (stream.status === 'live' && stream.agoraChannelId) {
      const viewerUid = req.user?.id || Math.floor(Math.random() * 1000000);
      const agoraAppId = getAgoraAppId();
      const agoraToken = generateAgoraSubscriberToken(stream.agoraChannelId, viewerUid);

      if (agoraAppId && agoraToken) {
        credentials = {
          appId: agoraAppId,
          channelName: stream.agoraChannelId, // BroadcasterView expects channelName
          token: agoraToken,
          uid: viewerUid,
        };
      }
    }

    return res.json({
      success: true,
      stream: streamWithFollowStatus,
      credentials,
    });
  } catch (error) {
    console.error('Get stream error:', error);
    return res.status(500).json({
      error: 'Internal Server Error',
      message: 'Failed to get stream',
    });
  }
}
