/**
 * Authentication Middleware
 * Verifies Firebase tokens and attaches user to request
 */

import type { Request, Response, NextFunction } from 'express';
import { verifyFirebaseToken } from '../services/firebase.js';
import { db } from '../db/client.js';
import { users } from '../db/schema.js';
import { eq } from 'drizzle-orm';

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        firebaseUid: string;
        username: string;
        email: string;
      };
    }
  }
}

/**
 * Middleware to verify Firebase token and load user
 */
export async function authenticateUser(req: Request, res: Response, next: NextFunction) {
  console.log('🎯 authenticateUser middleware called for:', req.method, req.path);
  
  try {
    const authHeader = req.headers.authorization;

    console.log('🔍 Auth middleware: Checking authorization header');

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.error('❌ No authorization header or invalid format');
      return res.status(401).json({ error: 'Unauthorized', message: 'No token provided' });
    }

    const idToken = authHeader.split('Bearer ')[1];
    console.log('🔍 Auth middleware: Token received, length:', idToken.length);

    const decodedToken = await verifyFirebaseToken(idToken);

    if (!decodedToken) {
      console.error('❌ Token verification failed');
      return res.status(401).json({ error: 'Unauthorized', message: 'Invalid token' });
    }

    console.log('✅ Token verified for Firebase UID:', decodedToken.uid);

    // Load user from database
    const userResult = await db
      .select()
      .from(users)
      .where(eq(users.firebaseUid, decodedToken.uid))
      .limit(1);

    if (userResult.length === 0) {
      console.error('❌ User not found in database for Firebase UID:', decodedToken.uid);
      return res.status(404).json({ error: 'Not Found', message: 'User not found in database' });
    }

    const user = userResult[0];
    console.log('✅ User loaded from database:', user.username);

    // Attach user to request
    req.user = {
      id: user.id,
      firebaseUid: user.firebaseUid,
      username: user.username,
      email: user.email,
    };

    next();
  } catch (error) {
    console.error('❌ Authentication error:', error);
    return res.status(500).json({ error: 'Internal Server Error', message: 'Authentication failed' });
  }
}

/**
 * Optional authentication - doesn't fail if no token
 */
export async function optionalAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }

    const idToken = authHeader.split('Bearer ')[1];
    const decodedToken = await verifyFirebaseToken(idToken);

    if (decodedToken) {
      const userResult = await db
        .select()
        .from(users)
        .where(eq(users.firebaseUid, decodedToken.uid))
        .limit(1);

      if (userResult.length > 0) {
        const user = userResult[0];
        req.user = {
          id: user.id,
          firebaseUid: user.firebaseUid,
          username: user.username,
          email: user.email,
        };
      }
    }

    next();
  } catch (error) {
    console.error('Optional auth error:', error);
    next();
  }
}
