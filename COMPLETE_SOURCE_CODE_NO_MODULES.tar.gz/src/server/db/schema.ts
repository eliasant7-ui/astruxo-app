/**
 * LiveStream Platform - Database Schema
 * Phase 1: Core MVP (Auth, Profiles, Follows, Streams, Chat)
 */

import { mysqlTable, int, varchar, text, decimal, timestamp, boolean, index } from 'drizzle-orm/mysql-core';
import { relations } from 'drizzle-orm';

// ============================================
// USERS TABLE
// ============================================
export const users = mysqlTable('users', {
  id: int('id').primaryKey().autoincrement(),
  firebaseUid: varchar('firebase_uid', { length: 128 }).notNull().unique(),
  username: varchar('username', { length: 50 }).notNull().unique(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  displayName: varchar('display_name', { length: 100 }),
  avatarUrl: text('avatar_url'),
  bio: text('bio'),
  followerCount: int('follower_count').default(0).notNull(),
  followingCount: int('following_count').default(0).notNull(),
  coinBalance: int('coin_balance').default(0).notNull(), // Virtual coins for gifts
  walletBalance: decimal('wallet_balance', { precision: 10, scale: 2 }).default('0.00').notNull(), // Real money earnings
  isLive: boolean('is_live').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  firebaseUidIdx: index('firebase_uid_idx').on(table.firebaseUid),
  usernameIdx: index('username_idx').on(table.username),
  isLiveIdx: index('is_live_idx').on(table.isLive),
}));

// ============================================
// FOLLOWS TABLE
// ============================================
export const follows = mysqlTable('follows', {
  id: int('id').primaryKey().autoincrement(),
  followerId: int('follower_id').notNull(),
  followingId: int('following_id').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  followerIdx: index('follower_idx').on(table.followerId),
  followingIdx: index('following_idx').on(table.followingId),
  uniqueFollow: index('unique_follow').on(table.followerId, table.followingId),
}));

// ============================================
// STREAMS TABLE
// ============================================
export const streams = mysqlTable('streams', {
  id: int('id').primaryKey().autoincrement(),
  userId: int('user_id').notNull(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description'),
  thumbnailUrl: text('thumbnail_url'),
  status: varchar('status', { length: 20 }).default('live').notNull(), // 'live', 'ended'
  agoraChannelId: varchar('agora_channel_id', { length: 255 }),
  viewerCount: int('viewer_count').default(0).notNull(),
  peakViewerCount: int('peak_viewer_count').default(0).notNull(),
  totalGiftsReceived: decimal('total_gifts_received', { precision: 10, scale: 2 }).default('0.00').notNull(),
  duration: int('duration'), // Duration in seconds
  startedAt: timestamp('started_at').defaultNow().notNull(),
  endedAt: timestamp('ended_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index('user_id_idx').on(table.userId),
  statusIdx: index('status_idx').on(table.status),
  startedAtIdx: index('started_at_idx').on(table.startedAt),
}));

// ============================================
// CHAT MESSAGES TABLE
// ============================================
export const chatMessages = mysqlTable('chat_messages', {
  id: int('id').primaryKey().autoincrement(),
  streamId: int('stream_id').notNull(),
  userId: int('user_id').notNull(),
  message: text('message').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  streamIdIdx: index('stream_id_idx').on(table.streamId),
  createdAtIdx: index('created_at_idx').on(table.createdAt),
}));

// ============================================
// GIFTS CATALOG TABLE
// ============================================
export const gifts = mysqlTable('gifts', {
  id: int('id').primaryKey().autoincrement(),
  name: varchar('name', { length: 50 }).notNull(),
  icon: varchar('icon', { length: 50 }).notNull(), // Lucide icon name
  coinPrice: int('coin_price').notNull(), // Price in coins
  animationType: varchar('animation_type', { length: 50 }).default('bounce').notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  sortOrder: int('sort_order').default(0).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  isActiveIdx: index('is_active_idx').on(table.isActive),
  sortOrderIdx: index('sort_order_idx').on(table.sortOrder),
}));

// ============================================
// GIFT TRANSACTIONS TABLE
// ============================================
export const giftTransactions = mysqlTable('gift_transactions', {
  id: int('id').primaryKey().autoincrement(),
  giftId: int('gift_id').notNull(),
  senderId: int('sender_id').notNull(), // User who sent the gift
  receiverId: int('receiver_id').notNull(), // Streamer who received
  streamId: int('stream_id').notNull(),
  coinAmount: int('coin_amount').notNull(),
  message: text('message'), // Optional message with gift
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  senderIdx: index('sender_idx').on(table.senderId),
  receiverIdx: index('receiver_idx').on(table.receiverId),
  streamIdx: index('stream_idx').on(table.streamId),
  createdAtIdx: index('created_at_idx').on(table.createdAt),
}));

// ============================================
// COIN TRANSACTIONS TABLE
// ============================================
export const coinTransactions = mysqlTable('coin_transactions', {
  id: int('id').primaryKey().autoincrement(),
  userId: int('user_id').notNull(),
  amount: int('amount').notNull(), // Positive for purchase, negative for spending
  type: varchar('type', { length: 20 }).notNull(), // 'purchase', 'gift_sent', 'gift_received', 'withdrawal'
  description: text('description'),
  referenceId: int('reference_id'), // ID of related transaction (gift, purchase, etc)
  stripeSessionId: varchar('stripe_session_id', { length: 255 }), // Stripe checkout session ID
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index('user_id_idx').on(table.userId),
  typeIdx: index('type_idx').on(table.type),
  createdAtIdx: index('created_at_idx').on(table.createdAt),
}));

// ============================================
// RELATIONS
// ============================================
export const usersRelations = relations(users, ({ many }) => ({
  streams: many(streams),
  followers: many(follows, { relationName: 'following' }),
  following: many(follows, { relationName: 'follower' }),
  chatMessages: many(chatMessages),
  giftsSent: many(giftTransactions, { relationName: 'sender' }),
  giftsReceived: many(giftTransactions, { relationName: 'receiver' }),
  coinTransactions: many(coinTransactions),
}));

export const followsRelations = relations(follows, ({ one }) => ({
  follower: one(users, {
    fields: [follows.followerId],
    references: [users.id],
    relationName: 'follower',
  }),
  following: one(users, {
    fields: [follows.followingId],
    references: [users.id],
    relationName: 'following',
  }),
}));

export const streamsRelations = relations(streams, ({ one, many }) => ({
  user: one(users, {
    fields: [streams.userId],
    references: [users.id],
  }),
  chatMessages: many(chatMessages),
  giftTransactions: many(giftTransactions),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  stream: one(streams, {
    fields: [chatMessages.streamId],
    references: [streams.id],
  }),
  user: one(users, {
    fields: [chatMessages.userId],
    references: [users.id],
  }),
}));

export const giftsRelations = relations(gifts, ({ many }) => ({
  transactions: many(giftTransactions),
}));

export const giftTransactionsRelations = relations(giftTransactions, ({ one }) => ({
  gift: one(gifts, {
    fields: [giftTransactions.giftId],
    references: [gifts.id],
  }),
  sender: one(users, {
    fields: [giftTransactions.senderId],
    references: [users.id],
    relationName: 'sender',
  }),
  receiver: one(users, {
    fields: [giftTransactions.receiverId],
    references: [users.id],
    relationName: 'receiver',
  }),
  stream: one(streams, {
    fields: [giftTransactions.streamId],
    references: [streams.id],
  }),
}));

export const coinTransactionsRelations = relations(coinTransactions, ({ one }) => ({
  user: one(users, {
    fields: [coinTransactions.userId],
    references: [users.id],
  }),
}));
